<?php 
include('connection.php');
extract($_REQUEST);
if(isset($send))
{
mysqli_query($con,"insert into feedback values('','$n','$e','$mob','$msg')");	
$msg= "<h4 style='color:green;'>feedback sent successfully</h4>";
}
?>
<!-- Footer1 Start Here-->

<footer style="background-color: #007bff;">
    <div class="container-fluid">
	<div class="col-sm-4 hov">
    <p class="text-justify">Un hôtel est un établissement qui propose un hébergement rémunéré à court terme. Les équipements fournis peuvent aller d'un matelas de qualité modeste dans une petite pièce à de grandes suites avec des lits plus grands et de meilleure qualité, une commode, un réfrigérateur et d'autres équipements de cuisine, des chaises rembourrées, une télévision à écran plat et une salle de bains privative. Les petits hôtels à bas prix peuvent n'offrir que les services et installations les plus basiques. Les hôtels plus grands et plus chers peuvent fournir des installations supplémentaires telles qu'une piscine, un centre d'affaires</p><br>
      <center><a href="about.php" class="btn btn-danger"><b>Read More..</b></a></center><br><br><br>
 <?php
  include('Social ican.php')
?>
	</div>&nbsp;&nbsp;
	<div class="col-sm-4 text-justify">
	       <h3 style="color:white;">Nous contacter</h3>
      <p style="color:white;"><strong>Address:&nbsp;</strong>MAROC,RABAT,AGDAL,59</p>
      <p style="color:white;"><strong>Email-Id:&nbsp;</strong>hotel@gmail.com</p>
      <p style="color:white;"><strong>Contact Us:&nbsp;</strong>(+212) 0589746235</p><br><br><br>
    
	</div>&nbsp;

  <!--Feedback Start Here-->
	<div class="col-sm-4 text-center">
      <div class="panel panel-primary">
        <div class="panel-heading">Feedback</div>
          <div class="panel-body">
            <?php echo @$msg; ?>
      <div class="feedback">
      <form method="post"><br>
        <div class="form-group">
          <input type="text" name="n" class="form-control" id="#"placeholder="Entrez votre nom"required>
        </div>
        <div class="form-group">
          <input type="Email" name="e" class="form-control" id="#"placeholder="Email"required>
        </div>
        <div class="form-group">
          <input type="Number" name="mob" class="form-control" id="#"placeholder="Numéro de portable"required>
        </div>
        <div class="form-group">
          <textarea type="Text" name="msg" class="form-control" id="#"placeholder="Tapez votre message"required></textarea>
        </div>
          <input type="submit" value="envoyer" name="send" class="btn btn-primary btn-group-justified"required>
      </form>     
        </div>
       </div>
      </div>
    </div>

    <!--Feedback Panel Close here-->

  </div>
</footer>
<!--Footer1 Close Here-->

<!--Footer2 start Here-->

<footer class="container-fluid text-center"style="background-color:#636e72;height:40px;padding-top:10px;color:#f0f0f0;">
  <p>Develope By alaa edine waladi  | All Rights Reserved 2020</p>
</footer>

<!--Footer2 close Here-->