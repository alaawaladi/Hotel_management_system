<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    #font{
      color: black;
      font-family: 'Courier Prime', monospace;
    }
  </style>
  <title>Paloma Hotel</title>
  <meta charset="utf-8">
  <link href="https://fonts.googleapis.com/css2?family=Courier+Prime:wght@700&display=swap" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="card.js"> </script>
  <link href="css/style.css"rel="stylesheet"/>
  <link rel="stylesheet" href="css/about.css"/>
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="margin-top:50px;">
<?php
      include('Menu Bar.php')
  ?><br>
<div class="container-fluid text-center">
<div class="container"> 
  <div class="row content">
    <div class="col-sm-12">
      <h1 id="font"> Paloma Hotel </h1><br>
      <!-- start for card section-->
      <section class="whole">
        <!-- first card start-->
     <div class="b1 df" id="one">
       <div class="title">
       <input type="text" id="search-bar" placeholder="Search..."/>
    <button id="toggle-theme">Dark</button>
  </div>
  <div class="m1">
  <img src="https://firebasestorage.googleapis.com/v0/b/d3-firebase-b8334.appspot.com/o/mountain.svg?alt=media&token=50c2e4bf-6dbf-4b0d-b3c4-928774d581a1" />
    <h1>Mountains</h1>
    <p>
      This is just a dummy text meant to fill up this space so that I can continue with my code. There’s nothing to learn from this text. Look at the code instead.
    </p>
  </div>
</div>
  </div>
       </div>
     </div>
     <div class="b3 df" id="two">
       <div class="title">
       <input type="text" id="search-bar" placeholder="Search..."/>
    <button id="toggle-theme">Dark</button>
  </div>
  <div class="m1">
  <img src="https://firebasestorage.googleapis.com/v0/b/d3-firebase-b8334.appspot.com/o/mountain.svg?alt=media&token=50c2e4bf-6dbf-4b0d-b3c4-928774d581a1" />
    <h1>Mountains</h1>
    <p>
      This is just a dummy text meant to fill up this space so that I can continue with my code. There’s nothing to learn from this text. Look at the code instead.
    </p>
  </div>
</div>
  </div>
       </div>
     </div>
     <div class="b2 df" id="there">
       <div class="title">
       <input type="text" id="search-bar" placeholder="Search..."/>
    <button id="toggle-theme">Dark</button>
  </div>
  <div class="m1">
  <img src="https://firebasestorage.googleapis.com/v0/b/d3-firebase-b8334.appspot.com/o/mountain.svg?alt=media&token=50c2e4bf-6dbf-4b0d-b3c4-928774d581a1" />
    <h1>Mountains</h1>
    <p>
      This is just a dummy text meant to fill up this space so that I can continue with my code. There’s nothing to learn from this text. Look at the code instead.
    </p>
  </div>
</div>
  </div>
       </div>
     </div>
     </section>
     <!-- end of first card -->
  <div class="row"align="center">
  <!--map Start Here-->
  <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px; border-radius: 50%;
      margin-left: 50px;">
      <a href="#" type="button" data-toggle="modal" data-target="#myModal"><img src="image/icon/icon-01.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
  </div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <iframe class="frame"src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.9012415990155!2d77.37085911440647!3d28.602739392180986!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce57ca5ff4435%3A0x6de631b7a5bfdacb!2sUnion+Bank+Of+India!5e0!3m2!1sen!2sin!4v1555502551059!5m2!1sen!2sin" width="550"height="300" frameborder="0" style="border:1" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div>      
<!--Map Close Here-->
        <div class="col-sm-2">
          <h4><b>Address</b></h4>
          <b>MAROC,RABAT,AGDAL,59</b>
        </div>
        <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px;border-radius: 50%;">
            <a href="#"><img src="image/icon/icon-02.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
        </div>
         <div class="col-sm-2">
          <h4><b>Phone</b></h4>
              <b>(+212) 0586426532</b>
        </div>
        <div class="col-sm-2"style="background-color:#27303b;height:80px;width:100px;border-radius: 50%;">
            <a href="#"><img src="image/icon/icon-03.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
        </div>
         <div class="col-sm-2">
          <h4><b>Email-Id</b></h4>
              <b>hotel@gmail.com</b>
        </div>
  </div><br><br>
</div>
</div>
<?php
  include('Footer.php')
?>
</body>
</html>
