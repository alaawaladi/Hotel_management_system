
<table class="table table-bordered table-striped table-hover">
	<h1> Détails de réservation de chambre</h1><hr>
	<tr>
		<th>Sr N</th>
		<th>Nom</th>
		<th>Email</th>
		<th>Mobile Number</th>
		<th>Adresse</th>
		<th>Type de chambre</th>
		<th>Date d'arrivée</th>
		<th>Heure de départ</th>
		<th>Date de départ</th>
		<th>Occupation</th>
		<th>Annuler la commande</th>
	</tr>

<?php 
$i=1;
$sql=mysqli_query($con,"select * from room_booking_details");
while($res=mysqli_fetch_assoc($sql))
{
$oid=$res['id'];

?>
<tr>
		<td><?php echo $i;$i++; ?></td>
		<td><?php echo $res['name']; ?></td>
		<td><?php echo $res['email']; ?></td>
		<td><?php echo $res['phone']; ?></td>
		<td><?php echo $res['address']; ?></td>
		<td><?php echo $res['room_type']; ?></td>
		<td><?php echo $res['check_in_date']; ?></td>
		<td><?php echo $res['check_in_time']; ?></td>
		<td><?php echo $res['check_out_date']; ?></td>
		<td><?php echo $res['Occupancy']; ?></td>
		<td><a style="color:red" href="cancel_order.php?booking_id=<?php echo $oid; ?>">Annuler</a></td>
	</td>
	</tr>
<?php 	
}

?>	
</table>