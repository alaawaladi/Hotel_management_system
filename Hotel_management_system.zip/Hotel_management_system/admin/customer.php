
<table class="table table-bordered table-striped table-hover">
	<h1 >Détails de la réservation client</h1><hr>
	<tr>
		<th>Sr N</th>
		<th>Nom</th>
		<th>Email</th>
		<th>Mobile Number</th>
		<th>Adresse</th>
		<th>Région</th>
		<th>Zip</th>
		<th>Etat</th>
		<th>Type de chambre</th>
		<th>Date d'arrivée</th>
		<th>Heure de départ</th>
		<th>Date de départ</th>
		<th>Occupation</th>
	</tr>

<?php 
$i=1;
$sql=mysqli_query($con,"select * from customer");
while($res=mysqli_fetch_assoc($sql))
{
?>
<tr>
		<td><?php echo $i;$i++; ?></td>
		<td><?php echo $res['name']; ?></td>
		<td><?php echo $res['email']; ?></td>
		<td><?php echo $res['phone']; ?></td>
		<td><?php echo $res['address']; ?></td>
		<td><?php echo $res['state']; ?></td>
		<td><?php echo $res['zip']; ?></td>
		<td><?php echo $res['contry']; ?></td>
		<td><?php echo $res['room_type']; ?></td>
		<td><?php echo $res['check_in_date']; ?></td>
		<td><?php echo $res['check_in_time']; ?></td>
		<td><?php echo $res['check_out_date']; ?></td>
		<td><?php echo $res['Occupancy']; ?></td>
	</td>
	</tr>
<?php 	
}

?>	
</table>