<?php 
if(isset($update))
{
$sql=mysqli_query($con,"select * from admin where username='$admin' and password='$op' ");
	if(mysqli_num_rows($sql))
	{
		if($np==$cp)
		{
		mysqli_query($con,"update admin set password='$np' where username='$admin' ");	
		echo "<h3 style='color:blue'>Password updated successfully</h3>";
		}
		else
		{
			echo "<h3 style='color:#dc3545;'>Nouveau et confirmer ne correspond pas</h3>";
		}
	}
	else
	{
	echo "<h3 style='color:#dc3545;'>L'ancien mot de passe ne correspond pas</h3>";	
	}
	
}
?>
<form method="post" enctype="multipart/form-data">
<table class="table table-bordered table-striped table-hover">
	<h1>Mettre à jour le mot de passe</h1><hr>
	<tr style="height:40">
		<th>Entrez votre ancien mot de passe</th>
		<td><input type="password" name="op" class="form-control"required/></td>
	</tr>
	
	<tr>	
		<th>Entrez votre nouveau mot de passe</th>
		<td><input type="password" name="np" class="form-control"required/>
		</td>
	</tr>
	
	<tr>	
		<th>Entrez votre mot de passe de confirmation</th>
		<td><input type="password" name="cp" class="form-control"required/>
		</td>
	</tr>
	
	<tr>
		<td colspan="2" align="center">
			<input type="submit" class="btn btn-primary" value="Mettre à jour le mot de passe" name="update"required/>
		</td>
	</tr>
</table> 
</form>